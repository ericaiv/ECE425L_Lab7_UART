# ECE 425L - Microprocessor Systems Lab
**CSU Northridge**

**Department of Electrical and Computer Engineering**

## UART Lab
