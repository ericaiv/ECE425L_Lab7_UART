/*
 * @file main.c
 *
 * @brief Main source code for the UART program.
 *
 * This file contains the main entry point and function definitions for the UART program.
 *
 * @note For more information regarding the UART module, refer to the
 * Universal Asynchronous Receivers / Transmitters (UARTs) section
 * of the TM4C123GH6PM Microcontroller Datasheet.
 *   - Link: https://www.ti.com/lit/gpn/TM4C123GH6PM
 *
 * @author
 */

#include "TM4C123GH6PM.h"

#include "SysTick_Delay.h"
#include "UART0.h"
#include "GPIO.h"
#include "string.h"
#include "UART1.h"

int main(void)
{
	SysTick_Delay_Init();
	UART0_Init();
	RGB_LED_Init();
	UART1_Init();
	int buffer = 64;
	char input[64];
	while(1)
	{
		
		//TASK 1
		/*
		UART0_Output_String("Enter Command: ");
		UART0_Input_String(input,buffer);
		UART0_Output_Newline();
		
		if(strcmp(input,"RGB LED RED") == 0)
		{
			RGB_LED_Output(RGB_LED_RED);
		}
		else if(strcmp(input,"RGB LED GREEN") == 0)
		{
			RGB_LED_Output(RGB_LED_GREEN);
		}
		else if(strcmp(input,"RGB LED BLUE") == 0)
		{
			RGB_LED_Output(RGB_LED_BLUE);
		}
		else if(strcmp(input,"RGB LED CYCLE") == 0)
		{
			RGB_LED_Output(RGB_LED_RED);
			SysTick_Delay1ms(500);
			RGB_LED_Output(RGB_LED_GREEN);
			SysTick_Delay1ms(500);
			RGB_LED_Output(RGB_LED_BLUE);
			SysTick_Delay1ms(500);
			RGB_LED_Output(RGB_LED_OFF);
		}
		else if(strcmp(input,"RGB LED OFF") == 0)
		{
			RGB_LED_Output(RGB_LED_OFF);
		}
		else
		{
			UART0_Output_String("Invalid command. Try again.");
		}
		*/
		
		UART1_Output_Character(0x55);
		SysTick_Delay1ms(500);
	}

}
